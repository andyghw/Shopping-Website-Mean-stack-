export class Customer{
    name:string;
    phone:number;
    address:string;
    card:number;
}