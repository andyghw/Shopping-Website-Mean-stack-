export class Question{
    content:string;
}