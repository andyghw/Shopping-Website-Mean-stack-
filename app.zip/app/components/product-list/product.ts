export class Product{
  name: String;
  price: string;
  description: String;
  location: String;
  image: String;
  _id:String;
  rating:string
}
