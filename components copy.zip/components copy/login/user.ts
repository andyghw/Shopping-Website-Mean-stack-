export class User{
  name: String;
  password: String;
  username: String;
  cartcontent: String;
  email: String;
  _id:String;
}
